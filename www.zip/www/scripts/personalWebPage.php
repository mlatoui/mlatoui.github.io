<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Form submission response</title>
    </head>
    <body>
        <div class="submission-response">
            <?php

                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    echo "Form successuly submitted :";
                    echo "<br>";
                    echo $_POST["name"];
                    echo "<br>";
                    echo $_POST["email"];
                    echo "<br>";
                    echo $_POST["subject"];
                    echo "<br>";
                    echo $_POST["message"];
                    } else {
                    die("Something went wrong, your form has not been successully submitted :-(");
                    }
                ?>
        </div>
    </body>
</html>
